// ---------- API base ----------
// Frontend and backend are served from the same Express app (see backend/server.js),
// so relative paths work whether it's run locally or deployed.
const API_BASE = '/api';

// ---------- Countdown to August 16 ----------
function getTargetDate(){
  const now = new Date();
  let year = now.getFullYear();
  let target = new Date(year, 7, 16, 0, 0, 0); // month 7 = August
  if(target < now){
    target = new Date(year + 1, 7, 16, 0, 0, 0);
  }
  return target;
}

function initCountdown(){
  const daysEl = document.getElementById('cd-days');
  if(!daysEl) return;
  function update(){
    const target = getTargetDate();
    const now = new Date();
    let diff = target - now;
    if(diff < 0) diff = 0;
    const days = Math.floor(diff / (1000*60*60*24));
    const hours = Math.floor((diff / (1000*60*60)) % 24);
    const mins = Math.floor((diff / (1000*60)) % 60);
    const secs = Math.floor((diff / 1000) % 60);
    document.getElementById('cd-days').textContent = days;
    document.getElementById('cd-hours').textContent = String(hours).padStart(2,'0');
    document.getElementById('cd-mins').textContent = String(mins).padStart(2,'0');
    document.getElementById('cd-secs').textContent = String(secs).padStart(2,'0');
  }
  update();
  setInterval(update, 1000);
}

// ---------- Ribbon canvas (dancing brushstrokes) ----------
function initRibbons(){
  const canvas = document.getElementById('ribbonCanvas');
  if(!canvas) return;
  const ctx = canvas.getContext('2d');
  let w, h, dpr;

  function resize(){
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    w = canvas.clientWidth;
    h = canvas.clientHeight;
    canvas.width = w * dpr;
    canvas.height = h * dpr;
    ctx.setTransform(dpr,0,0,dpr,0,0);
  }
  window.addEventListener('resize', resize);
  resize();

  const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  const ribbons = [
    { color: 'rgba(255,111,94,0.35)', amp: 60, speed: 0.6, freq: 1.4, yOff: 0.28, width: 3 },
    { color: 'rgba(232,184,75,0.3)',  amp: 80, speed: 0.45, freq: 1.1, yOff: 0.5,  width: 2.4 },
    { color: 'rgba(63,189,176,0.28)', amp: 50, speed: 0.7, freq: 1.7, yOff: 0.72, width: 2 }
  ];

  let t = 0;
  function draw(){
    ctx.clearRect(0,0,w,h);
    ribbons.forEach((r) => {
      ctx.beginPath();
      for(let x = 0; x <= w; x += 6){
        const y = h*r.yOff + Math.sin((x*0.006*r.freq) + t*r.speed) * r.amp
                 + Math.sin((x*0.002) - t*r.speed*0.5) * r.amp*0.4;
        if(x === 0) ctx.moveTo(x,y);
        else ctx.lineTo(x,y);
      }
      ctx.strokeStyle = r.color;
      ctx.lineWidth = r.width;
      ctx.lineCap = 'round';
      ctx.stroke();
    });
    if(!prefersReduced){
      t += 0.02;
      requestAnimationFrame(draw);
    }
  }
  draw();
}

// ---------- Gift page: copy number ----------
function initCopyButton(){
  const btn = document.getElementById('copyBtn');
  if(!btn) return;
  btn.addEventListener('click', async () => {
    const number = btn.getAttribute('data-number');
    const feedback = document.getElementById('copyFeedback');
    try{
      await navigator.clipboard.writeText(number);
      feedback.textContent = 'Copied to clipboard';
    }catch(e){
      feedback.textContent = number;
    }
    setTimeout(() => { feedback.textContent = ''; }, 2500);
  });
}

// ---------- Guestbook form ----------
function initMessageForm(){
  const form = document.getElementById('messageForm');
  if(!form) return;
  const status = document.getElementById('formStatus');
  const submitBtn = form.querySelector('.submit-btn');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = form.name.value.trim();
    const message = form.message.value.trim();
    const sentGift = form.sentGift.checked;

    if(!name || !message){
      status.textContent = 'Please add your name and a message.';
      status.className = 'form-status error';
      return;
    }

    submitBtn.disabled = true;
    status.textContent = '';
    status.className = 'form-status';

    try{
      const res = await fetch(`${API_BASE}/messages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, message, sentGift })
      });
      if(!res.ok) throw new Error('Request failed');
      status.textContent = 'Thank you — your message is on the wall.';
      status.className = 'form-status success';
      form.reset();
    }catch(err){
      status.textContent = 'Something went wrong. Please try again.';
      status.className = 'form-status error';
    }finally{
      submitBtn.disabled = false;
    }
  });
}

// ---------- Message wall ----------
function initMessageWall(){
  const wall = document.getElementById('messageWall');
  if(!wall) return;

  fetch(`${API_BASE}/messages`)
    .then(res => res.json())
    .then(messages => {
      if(!messages.length){
        wall.innerHTML = '<div class="wall-empty">No messages yet — be the first to write one on the Gift page.</div>';
        return;
      }
      wall.innerHTML = messages
        .slice()
        .reverse()
        .map(m => `
          <div class="wall-item">
            <div class="wall-item-head">
              <span class="wall-name">${escapeHtml(m.name)}</span>
              ${m.sentGift ? '<span class="wall-tag">Sent a gift 🎁</span>' : ''}
            </div>
            <div class="wall-text">${escapeHtml(m.message)}</div>
            <div class="wall-time">${new Date(m.createdAt).toLocaleString()}</div>
          </div>
        `).join('');
    })
    .catch(() => {
      wall.innerHTML = '<div class="wall-empty">Couldn\'t load messages right now.</div>';
    });
}

function escapeHtml(str){
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

// ---------- Nav active link ----------
function markActiveNav(){
  const path = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-links a').forEach(a => {
    if(a.getAttribute('href') === path) a.classList.add('active');
  });
}

document.addEventListener('DOMContentLoaded', () => {
  initCountdown();
  initRibbons();
  initCopyButton();
  initMessageForm();
  initMessageWall();
  markActiveNav();
});
