# Dorin's Birthday Site

A gift site from Travis & Shiner — art, animation, dancing — counting down to August 16.

## What was broken in the last version

1. **Folder names had trailing spaces** — `frontend ` and `resources ` instead of `frontend` and `resources`. Netlify's publish directory setting (`frontend`) didn't match the actual folder (`frontend `), so it likely deployed nothing, or deployed the wrong thing. Fixed: folders are now named exactly `frontend`, no spaces.
2. **No `netlify.toml` and no `netlify/functions` folder existed in that zip** — only the old `backend/` Express server was there. Netlify can't run Express (it's not a persistent server host), so the guestbook form had nothing to post to. That's why messages weren't saving.
3. **Gallery had no real images wired in** — it was still the placeholder version. Your 16 photos were sitting in `resources /` but nothing on any page referenced them.

## What's fixed now

- Folder structure is clean: `frontend/`, `netlify/functions/`, `backend/` (optional), all with normal names.
- Your 16 photos are moved into `frontend/images/gallery/` and the Gallery page now shows them in a real masonry grid with click-to-enlarge.
- `netlify.toml` + `netlify/functions/messages.js` are back in, using **Netlify Blobs** for storage (Netlify's built-in key-value store — no separate database to set up).

## Structure

```
dorin-birthday-site/
├── netlify.toml            build config + /api/* redirect to the function
├── package.json             root deps (@netlify/blobs)
├── frontend/                 published to Netlify
│   ├── index.html
│   ├── gallery.html          real photos, masonry grid + lightbox
│   ├── gift.html             M-Pesa instructions + guestbook form
│   ├── messages.html         guestbook wall
│   ├── images/gallery/       your 16 photos
│   ├── css/style.css
│   └── js/main.js
├── netlify/functions/
│   └── messages.js           guestbook API (GET/POST), backed by Netlify Blobs
└── backend/                   Express version — only if hosting elsewhere (Render/Railway/VPS), NOT Netlify
```

## Deploying on Netlify

1. Push this whole folder to a GitHub/GitLab repo (as-is — don't rename or nest the folders further).
2. In Netlify: **Add new site → Import an existing project**, select the repo.
3. Confirm build settings (should auto-fill from `netlify.toml`):
   - Publish directory: `frontend`
   - Functions directory: `netlify/functions`
4. Deploy. Netlify installs `@netlify/blobs` automatically from the root `package.json`.
5. Open the deployed URL. Check the Gift page — submit a test message, then check the Guestbook page to confirm it shows up.

**Testing locally before deploying** (recommended so you catch issues before Netlify does):
```bash
npm install -g netlify-cli
netlify dev
```
This runs the site + functions together at `http://localhost:8888`, matching how it'll behave once deployed.

## If it still fails to deploy

Send me the exact Netlify build log / error message and I'll debug the specific line — "it doesn't work" without the log is hard to diagnose blind, but with the log it's usually a one-line fix.

## Running the Express version instead (non-Netlify hosts)

```bash
cd backend
npm install
npm start
```
Then open **http://localhost:3000**.
