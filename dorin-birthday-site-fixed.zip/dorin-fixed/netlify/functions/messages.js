const { getStore } = require('@netlify/blobs');
const crypto = require('crypto');

const STORE_NAME = 'guestbook';
const KEY = 'messages';

function jsonResponse(statusCode, data) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  };
}

exports.handler = async (event) => {
  const store = getStore(STORE_NAME);

  if (event.httpMethod === 'GET') {
    const messages = (await store.get(KEY, { type: 'json' })) || [];
    return jsonResponse(200, messages);
  }

  if (event.httpMethod === 'POST') {
    let body;
    try {
      body = JSON.parse(event.body || '{}');
    } catch (err) {
      return jsonResponse(400, { error: 'Invalid JSON body.' });
    }

    const { name, message, sentGift } = body;

    if (typeof name !== 'string' || !name.trim() ||
        typeof message !== 'string' || !message.trim()) {
      return jsonResponse(400, { error: 'Name and message are required.' });
    }

    const entry = {
      id: crypto.randomUUID(),
      name: name.trim().slice(0, 60),
      message: message.trim().slice(0, 500),
      sentGift: Boolean(sentGift),
      createdAt: new Date().toISOString()
    };

    const messages = (await store.get(KEY, { type: 'json' })) || [];
    messages.push(entry);
    await store.setJSON(KEY, messages);

    return jsonResponse(201, entry);
  }

  return jsonResponse(405, { error: 'Method not allowed.' });
};
