const express = require('express');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, 'data', 'messages.json');
const FRONTEND_DIR = path.join(__dirname, '..', 'frontend');

app.use(express.json());

// ---------- Serve the static frontend ----------
app.use(express.static(FRONTEND_DIR));

// ---------- Helpers ----------
function readMessages(){
  try{
    const raw = fs.readFileSync(DATA_FILE, 'utf-8');
    return JSON.parse(raw);
  }catch(err){
    return [];
  }
}

function writeMessages(messages){
  fs.writeFileSync(DATA_FILE, JSON.stringify(messages, null, 2));
}

// ---------- API: gift info ----------
// NOTE: This is a personal M-Pesa number, not a registered Paybill/Till.
// That means there is no API-based way to auto-confirm a payment was made -
// Safaricom's Daraja STK Push / C2B confirmation APIs require a business
// shortcode. This endpoint exists so the frontend never hardcodes the number
// twice, and so it's easy to update in one place if it ever changes.
app.get('/api/gift-info', (req, res) => {
  res.json({
    method: 'mpesa_send_money',
    number: '0726949221',
    displayNumber: '0726 949 221',
    instructions: [
      'Open M-Pesa on your phone or the app',
      'Select Send Money',
      'Enter 0726 949 221',
      'Enter your amount and confirm with your PIN',
      'Leave a note on the guestbook so Dorin knows it was you'
    ]
  });
});

// ---------- API: messages / guestbook ----------
app.get('/api/messages', (req, res) => {
  res.json(readMessages());
});

app.post('/api/messages', (req, res) => {
  const { name, message, sentGift } = req.body || {};

  if(typeof name !== 'string' || !name.trim() ||
     typeof message !== 'string' || !message.trim()){
    return res.status(400).json({ error: 'Name and message are required.' });
  }

  // Basic length guards to keep the guestbook sane
  const cleanName = name.trim().slice(0, 60);
  const cleanMessage = message.trim().slice(0, 500);

  const entry = {
    id: crypto.randomUUID(),
    name: cleanName,
    message: cleanMessage,
    sentGift: Boolean(sentGift),
    createdAt: new Date().toISOString()
  };

  const messages = readMessages();
  messages.push(entry);
  writeMessages(messages);

  res.status(201).json(entry);
});

app.listen(PORT, () => {
  console.log(`Dorin's birthday site running at http://localhost:${PORT}`);
});
